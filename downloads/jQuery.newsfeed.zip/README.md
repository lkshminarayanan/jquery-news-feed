jquery-news-feed
================

A jquery plugin to create news feed 